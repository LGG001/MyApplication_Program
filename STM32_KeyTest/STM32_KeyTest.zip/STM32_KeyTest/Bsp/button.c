/**
  ******************************************************************************
  * @文件         button.c
  * @作者         LGG
  * @版本         V1.0.0
  * @日期         2018-10-27
  * @摘要         button源文件
  ******************************************************************************
*/ 


#include "button.h"


//键值表
const KEY_Table key_tab[]=
{
	{KEY1_VALUE,	KEY1_Pressed,	KEY1_LongPressed,	Pressed, Long_Pressed},		//KEY1-短按-长按
	{KEY2_VALUE, 	KEY2_Pressed,	KEY2_LongPressed,	Pressed, Long_Pressed},		//KEY2-短按-长按
	{KEY3_VALUE, 	KEY3_Pressed,	KEY3_LongPressed,	Pressed, Long_Pressed},		//KEY3-短按-长按
	{KEY4_VALUE,	KEY4_Pressed,	KEY4_LongPressed,	Pressed, Long_Pressed},		//KEY4-短按-长按
	{KEY5_VALUE,	KEY5_Pressed,	KEY5_LongPressed,	Pressed, Long_Pressed},		//KEY5-短按-长按
	{KEY6_VALUE,	KEY6_Pressed,	KEY6_LongPressed,	Pressed, Long_Pressed},		//KEY6-短按-长按
};



/**
  * @函数名       KEY_Init
  * @功  能       KEY1~KEY6初始化配置
  * @参  数       无
  * @返回值       无
  */
void KEY_Init(void)
{	
	GPIO_InitTypeDef  GPIO_InitStructure;					// 定义GPIO_InitTypeDef型结构体
	RCC_APB2PeriphClockCmd(KEY_CLOCK, ENABLE);				// 使能LED1&LED2端口时钟
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 			// 上拉输入
	GPIO_Init(GPIOB, &GPIO_InitStructure);					// 初始化配置		
}


/**
  * @函数名       check_user_key
  * @功  能       按键扫描
  * @参  数       无
  * @返回值       key_value：键值
  */
key_value KEY_Scan(void)
{
	static key_status state;							//按键状态
	static key_time 	time;							//按键消抖和释放的时间
	volatile key_value KEY_Value = NULL_Pressed;		//键值，初始为空
	static unsigned char i;								//扫描键值表计数：i
	unsigned int key_temp;
	
	key_temp = (GPIO_ReadInputData(GPIOB) & KEY_VALUE);	//读取键值
	if(key_temp != KEY_VALUE)							//判断是否有按键按下
	{
		time.Time_Release = RELEASE_TIMES;				//有按键按下（在按下的状态），赋值释放时间	
		switch(state)									//判断上一次按键的状态
		{
			case IDLE:									//空闲状态
				time.Time_Debounce = DEBOUNCE_TIMES;	//赋值消抖时间
				state = Debounce;						//将状态改为消抖状态
				break;									//退出
				
			case Debounce:								//消抖状态
				if(--time.Time_Debounce == 0)			//消抖完成
				{
					time.Time_LongPressed = LONG_PRESSED_TIMES;	//长按的时间赋值
					
					for(i=0; ;i++)								//循环查询键值表
					{
						if(key_temp == key_tab[i].Index)		//循环查询索引
						{
							state = key_tab[i].State1;			//对应索引的状态为按下（PRESSED）
							break;								//退出循环
						}
						else if(i >= 6)							//超出按键扫描范围，或同时按到其他按键
						{
							state=IDLE;							//把状态重新配置为空闲
							return NULL_Pressed;				//返回空值
						}
					}
				}
				break;
				
			case Pressed:									//按键按下状态
				if(--time.Time_LongPressed == 0)			//长按消抖完成
				{
					for(i=0; ;i++)							//循环查询键值表
					{
						if(key_temp == key_tab[i].Index)	//重新循环查询索引
						{
							state = key_tab[i].State2;		//对应索引的状态为长按（LONG_PRESSED）
							break;							//退出循环
						}
						else if(i > 6)						//超出按键扫描范围，或同时按到其他按键
						{
							state=IDLE;						//把状态重新配置为空闲
							return NULL_Pressed;			//返回空值
						}
					}
				}
				break;
				

			case Long_Pressed:							//一直保持长按，退出，不处理
				break;
				
			default:									//其他情况，将状态设为空闲，退出
				state=IDLE;
				break;
		}
	}
	else
	{
		if(time.Time_Release != 0)						//判断按键是否已经释放完成（空闲状态时stkey.release一直等于0）
		{
			if(--time.Time_Release == 0)				//如果按键已经释放
			{
				switch(state)
				{
					case Pressed:						//按键按下，返回单击键值
						KEY_Value=key_tab[i].Value1;
						state=IDLE;						//将状态设为空闲
						break;
						
					case Long_Pressed:					//按键长按，返回按键长按键值
						KEY_Value=key_tab[i].Value2;
						state=IDLE;						//将状态设为空闲
						break;
						
					default:							//其他情况（消抖期间释放，或一直没按键按下），将状态设为空闲，退出
						state=IDLE;
						break;
				}
			}
		}
	}
	return KEY_Value;									//返回键值
}


/**
  * @函数名       KeyProcess
  * @功  能       按键处理，根据键值来执行相应的操作
  * @参  数       key_val：键值
  * @返回值       无
  */
void KEY_Process(key_value key_value)
{
	switch(key_value)
	{
		case KEY1_Pressed:					//KEY1按下（短按）
			printf("KEY1_Pressed! \r\n");	//打印信息
			break;

		case KEY2_Pressed:					//KEY2按下（短按）
			printf("KEY2_Pressed! \r\n");	//打印信息
			break;
			
		case KEY3_Pressed:					//KEY3按下（短按）
			printf("KEY3_Pressed! \r\n");	//打印信息
			break;
			
		case KEY4_Pressed:					//KEY4按下（短按）
      		printf("KEY4_Pressed! \r\n");   //打印信息                                                                                                                                                                                                                                                                                                    		
			break;
			
		case KEY5_Pressed:					//KEY5按下（短按）
			printf("KEY5_Pressed! \r\n");	//打印信息
			break;
		
		case KEY6_Pressed:					//KEY6按下（短按）
			printf("KEY6_Pressed! \r\n");	//打印信息
			break;
			
		case KEY1_LongPressed:					//KEY1长按
			printf("KEY1_LongPressed! \r\n");	//打印信息
			break;
			
		case KEY2_LongPressed:					//KEY2长按
			printf("KEY2_LongPressed! \r\n");	//打印信息
			break;
			
		case KEY3_LongPressed:					//KEY3长按
			printf("KEY3_LongPressed! \r\n");	//打印信息
			break;
			
		case KEY4_LongPressed:					//KEY4长按
			printf("KEY4_LongPressed! \r\n");	//打印信息
			break;
			
		case KEY5_LongPressed:					//KEY5长按
			printf("KEY5_LongPressed! \r\n");	//打印信息
			break;
		
		case KEY6_LongPressed:					//KEY6长按
			printf("KEY6_LongPressed! \r\n");	//打印信息
			break;

		default:								//其他
			break;
	}
}

