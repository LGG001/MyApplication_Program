/**
  ******************************************************************************
  * @文件         button.h
  * @作者         LGG
  * @版本         V1.0.0
  * @日期         2018-10-27
  * @摘要         button头文件
  ******************************************************************************
*/ 


/* 包含头文件 ----------------------------------------------------------------*/
#include "stm32f10x.h"


/* 定义防止递归包含 ----------------------------------------------------------*/
#ifndef __BUTTON_H
#define __BUTTON_H


/* 包含头文件 ----------------------------------------------------------------*/
#include "stm32f10x.h"
#include "uart.h"


#define	RELEASE_TIMES			3			//按键释放时间
#define	DEBOUNCE_TIMES			5			//按键消抖时间
#define	LONG_PRESSED_TIMES		200			//按键长按时间



#define KEY_VALUE		0x3c03			//没按键按下的键值
#define KEY1_VALUE		0x3c02			//KEY1按下的键值
#define KEY2_VALUE		0x3c01			//KEY2按下的键值
#define KEY3_VALUE		0x3803			//KEY3按下的键值
#define KEY4_VALUE		0x3403			//KEY4按下的键值
#define KEY5_VALUE		0x2c03			//KEY5按下的键值
#define KEY6_VALUE		0x1c03			//KEY6按下的键值



typedef enum
{
	IDLE,			//空闲
	Debounce,		//消抖
	Pressed,		//按下
	Long_Pressed,	//长按
	Release,		//释放
}key_status;		//按键状态


typedef enum
{
	NULL_Pressed=0,		//无按键按下
	KEY1_Pressed,		//KEY1按下（短按）
	KEY2_Pressed,		//KEY2按下（短按）
	KEY3_Pressed,		//KEY3按下（短按）
	KEY4_Pressed,		//KEY4按下（短按）
	KEY5_Pressed,		//KEY5按下（短按）
	KEY6_Pressed,		//KEY6按下（短按）
	KEY1_LongPressed,	//KEY1长按
	KEY2_LongPressed,	//KEY2长按
	KEY3_LongPressed,	//KEY3长按
	KEY4_LongPressed,	//KEY4长按
	KEY5_LongPressed,	//KEY5长按
	KEY6_LongPressed,	//KEY6长按
}key_value;				//键值


typedef struct
{
	unsigned int Time_Debounce;			//消抖时间
	unsigned int Time_LongPressed;		//长按时间
	unsigned int Time_Release;			//释放时间
}key_time;				//消抖、长按&释放时间


typedef struct
{
	unsigned int Index;				//按键索引(按键按下的键值)
	key_value Value1;				//键值1（KEYx按下）
	key_value Value2;				//键值2（KEYx长按）
	key_status State1;				//按键状态1（按下状态）
	key_status State2;				//按键状态2（长按状态）
}KEY_Table;



/* 宏定义 --------------------------------------------------------------------*/
#define KEY_CLOCK				RCC_APB2Periph_GPIOB	//按键时钟




/* 函数声明-------------------------------------------------------------------*/
void KEY_Init(void);	
key_value KEY_Scan(void);
void KEY_Process(key_value key_value);

#endif
