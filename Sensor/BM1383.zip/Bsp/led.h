/**
  ******************************************************************************
  * @�ļ�         led.h
  * @����         LGG
  * @�汾         V1.0.0
  * @����         2018-11-27
  * @ժҪ         ledͷ�ļ�
  ******************************************************************************
*/ 


/* �����ֹ�ݹ���� ----------------------------------------------------------*/
#ifndef __LED_H
#define __LED_H


/* �궨�� --------------------------------------------------------------------*/
#define LED1_CLOCK				RCC_APB2Periph_GPIOB
#define LED2_CLOCK				RCC_APB2Periph_GPIOB

#define	LED1_PORT					GPIOB
#define	LED1_PIN					GPIO_Pin_14

#define	LED2_PORT					GPIOB
#define	LED2_PIN					GPIO_Pin_15


#define	LED1_ON						(PBout(0) = 0)
#define	LED2_ON						(PBout(1) = 0)

#define LED1_OFF					(PBout(0) = 1)
#define LED2_OFF					(PBout(1) = 1)

#define LED1_TOGGLE				(PBout(0) = !PBout(0))
#define LED2_TOGGLE				(PBout(1) = !PBout(1))


/* ��������-------------------------------------------------------------------*/
void LED_Init(void);	

#endif

