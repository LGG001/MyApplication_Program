/**
  ******************************************************************************
  * @�ļ�         my_iic.h
  * @����         LGG
  * @�汾         V1.0.0
  * @����         2019-03-06
  * @ժҪ         my_iicͷ�ļ�
  ******************************************************************************
*/ 


/* �����ֹ�ݹ���� ----------------------------------------------------------*/
#ifndef __MY_IIC_H
#define __MY_IIC_H


#define IIC_SCL_CLOCK			RCC_APB2Periph_GPIOB
#define IIC_SDA_CLOCK			RCC_APB2Periph_GPIOB

#define	IIC_SCL_PORT			GPIOB
#define	IIC_SDA_PORT			GPIOB

#define IIC_SCL_PIN				GPIO_Pin_8
#define IIC_SDA_PIN				GPIO_Pin_9

#define IIC_SCL_LOW				(IIC_SCL_PORT->BRR = IIC_SCL_PIN)
#define IIC_SDA_LOW				(IIC_SDA_PORT->BRR = IIC_SDA_PIN)
#define IIC_SCL_HIGH			(IIC_SCL_PORT->BSRR = IIC_SCL_PIN)
#define IIC_SDA_HIGH			(IIC_SDA_PORT->BSRR = IIC_SDA_PIN)

#define IIC_SCL_READ			(IIC_SCL_PORT->IDR & IIC_SCL_PIN)
#define IIC_SDA_READ			(IIC_SDA_PORT->IDR & IIC_SDA_PIN)

//#define	IIC_Clock_Stretching	


//ö��IICӦ��/��Ӧ��
typedef enum {
	IIC_ACK = 0,									//IICӦ��
	IIC_NACK = 1,									//IIC��Ӧ��
}et_IIC_ACK;


//ö��IICͨ�Ź��̵�״̬
typedef enum {
	IIC_NO_ERROR = 0,							//IIC״̬����
	IIC_BUSY_ERROR = 1,						//IICæ
	IIC_NACK_ERROR = 2,						//IICû��Ӧ��
	IIC_TIMEOUT_ERROR = 3,				//IIC��ʱ
}et_IIC_ERROR;


/* ��������-------------------------------------------------------------------*/
void IIC_GPIO_Init(void);
void IIC_Start(void);
void IIC_Stop(void);
et_IIC_ERROR IIC_WirteByte(uint8_t TxByte);
et_IIC_ERROR IIC_ReadByte(uint8_t *RxByte, et_IIC_ACK ack);




#endif
