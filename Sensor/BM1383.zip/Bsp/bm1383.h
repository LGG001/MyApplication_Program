/**
  ******************************************************************************
  * @�ļ�         bm1383.h
  * @����         LGG
  * @�汾         V1.0.0
  * @����         2019-03-06
  * @ժҪ         bm1383ͷ�ļ�
  ******************************************************************************
*/ 


/* �����ֹ�ݹ���� ----------------------------------------------------------*/
#ifndef __BM1383_H
#define __BM1383_H


/* ����ͷ�ļ� ----------------------------------------------------------------*/
#include "stm32f10x.h"


#define DRDY_CLOCK									RCC_APB2Periph_GPIOB
#define DRDY_PORT										GPIOB
#define DRDY_PIN										GPIO_Pin_7


#define BM1383_ID										0xE032
#define BM1383_ADDR									0xBA


//BM1383��ؼĴ�����ַ
#define BM1383_ID1									0x0F
#define BM1383_ID2									0x10
#define BM1383_PowerDown						0x12
#define BM1383_Reset								0x13
#define BM1383_ModeControl					0x14
#define BM1383_Status								0x19
#define BM1383_PressureMsb					0x1A
#define BM1383_PressureLsb1					0x1B
#define BM1383_PressureLsb2					0x1C
#define BM1383_TemperatureMsb				0x1D
#define BM1383_TemperatureLsb				0x1E


#define	Time_6_60										0x00
#define	Time_9_60										0x20
#define	Time_16_60									0x40
#define	Time_30_60									0x60
#define	Time_60_60									0x80
#define	Time_120_60									0xA0
#define	Time_240_60									0xC0


#define Mode_StandBy								0x01
#define Mode_OneShot								0x01
#define Mode_Continuous							0x01
#define Mode_Prohibition						0x01



//ö�ٲ���ʱ��
typedef enum
{
	AVE_NUM_1 = 0,
	AVE_NUM_2,
	AVE_NUM_3,
	AVE_NUM_4,
	AVE_NUM_5,
	AVE_NUM_6,
	AVE_NUM_7,
}et_Measurement_Time;



typedef struct
{
	uint8_t PressureMsb;
	uint8_t PressureLsb1;
	uint8_t PressureLsb2;
	uint8_t TemperatureMsb;
	uint8_t TemperatureLsb;
	uint32_t Pressure_Value;
	uint32_t Temperature_Value;
}BM1383_Data;


void BM1383_Init(void);
et_IIC_ERROR BM1383_WriteReg(uint8_t Reg_Addr, uint8_t Reg_Data);
et_IIC_ERROR BM1383_ReadReg(uint8_t Reg_Addr, uint8_t *Reg_Data);
et_IIC_ERROR BM1383_ReadID(uint16_t *ID_Data);
et_IIC_ERROR BM1383_OneShot_ReadData(BM1383_Data	*My_Data);


#endif  

